# Stock Truth: NOVA CART Rescue (Prompt Wars)

**Live demo:** _add your GitHub Pages link here_

## 1. Problem Diagnosis
NOVA CART's growth is bought, not earned.
- Promo spend +79% (₹9.5L → ₹17L), yet revenue after promo fell ₹12.3L → ₹9.1L (−26%).
- Repeat purchase rate fell 41% → 27%; MAU grew only 18% while registered users grew 46%.
- 53% of cancellations are supply-side (35% product unavailable + 18% store rejected), about 5.8% of all orders.
- 61% of churned users had rated the app 4★+. They were let down on reliability, not disliked.
- 39% of stores say inventory upkeep is too much effort; some update only every 1–3 days.

**Root cause:** stale inventory makes the app promise stock that stores don't have. That drives cancellations, refunds, support tickets and lost trust, so extra acquisition spend refills a leaking bucket.

## 2. Solution: Stock Truth
- **Store side:** one-tap "In stock / Out" on the riskiest items first (fast-selling and stale), with a reliability score and a demand-gap feed.
- **Customer side:** each item gets an availability-confidence score = exp(−hours since confirmed × (0.03 + 0.05 × sales velocity)). Search is ranked by confidence, then distance.
- **Checkout:** low-confidence items trigger a store ping, and out-of-stock items are caught before payment with a suggested substitute.
- **Business impact tab:** adjustable model for recovered orders, repeat lift, support savings and promo shift.

## 3. Business Impact (default assumptions, editable in the app)
~₹4.9L/month value, about 3-month payback on a ₹15L build (cap ₹25L). Assumptions: 13.9% take rate, ₹70 per support ticket, 60% of supply-side cancellations prevented, +6 pt repeat rate.

## 4. Prompt Journey
1. "Compute net revenue after promo and cost per order, then rank which management claim the data supports."
2. "Trace each cancellation, ticket and survey signal back to one root cause."
3. "Challenge my diagnosis: what would make Marketing right?"
4. "Design the smallest product that fixes the root cause under ₹25L."

## 5. Demo (2 min)
Diagnosis tab → search "eggs" → add Amul Taaza Milk and place order (stale listing caught, swap suggested) → Store tab one-tap update → search "saline" (demand gap) → Impact sliders.

## Run
Single static file: open `index.html` in a browser. Inventory data is simulated.
